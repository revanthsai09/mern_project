/* ============================================================
   PORTFOLIO — MAIN JS
   ============================================================ */

// ─── Loader ──────────────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('loader').classList.add('done');
    document.body.classList.remove('loading');
    triggerHeroReveal();
  }, 1600);
});

function triggerHeroReveal() {
  document.querySelectorAll('.hero .reveal-up, .hero .reveal-float').forEach((el, i) => {
    setTimeout(() => el.classList.add('visible'), i * 120);
  });
}

// ─── Custom Cursor ───────────────────────────────────────────
const cursor = document.getElementById('cursor');
const cursorLabel = document.getElementById('cursorLabel');
let cX = 0, cY = 0, tX = 0, tY = 0;

if (cursor) {
  document.addEventListener('mousemove', e => {
    tX = e.clientX; tY = e.clientY;
  });

  (function animCursor() {
    cX += (tX - cX) * 0.12;
    cY += (tY - cY) * 0.12;
    cursor.style.left = cX + 'px';
    cursor.style.top = cY + 'px';
    requestAnimationFrame(animCursor);
  })();

  document.querySelectorAll('a, button, .skill-cat, .proj-card, .pf-btn').forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursor.classList.add('expanded');
      const label = el.dataset.cursor || '';
      cursorLabel.textContent = label;
    });
    el.addEventListener('mouseleave', () => {
      cursor.classList.remove('expanded');
      cursorLabel.textContent = '';
    });
  });
}

// ─── Header on Scroll ────────────────────────────────────────
const header = document.getElementById('header');
window.addEventListener('scroll', () => {
  header.classList.toggle('solid', window.scrollY > 60);
}, { passive: true });

// ─── Mobile Menu ─────────────────────────────────────────────
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  mobileMenu.classList.toggle('open');
  document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
});

mobileMenu.querySelectorAll('.mm-link').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
    document.body.style.overflow = '';
  });
});

// ─── Active nav link ─────────────────────────────────────────
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
  let cur = '';
  sections.forEach(sec => {
    if (window.scrollY >= sec.offsetTop - 160) cur = sec.id;
  });
  navLinks.forEach(link => {
    link.classList.toggle('active', link.getAttribute('href') === '#' + cur);
  });
}, { passive: true });

// ─── Dot Canvas Background ───────────────────────────────────
const canvas = document.getElementById('dotCanvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  let dots = [], mouse = { x: -999, y: -999 };
  const DOT_COUNT = 120;

  function resize() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    createDots();
  }

  function createDots() {
    dots = [];
    for (let i = 0; i < DOT_COUNT; i++) {
      dots.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        r: Math.random() * 1.5 + 0.5,
      });
    }
  }

  document.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
  });

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    dots.forEach(d => {
      d.x += d.vx; d.y += d.vy;
      if (d.x < 0 || d.x > canvas.width) d.vx *= -1;
      if (d.y < 0 || d.y > canvas.height) d.vy *= -1;

      const dx = d.x - mouse.x, dy = d.y - mouse.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 120) {
        d.x += dx / dist * 1.2;
        d.y += dy / dist * 1.2;
      }

      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(200,255,0,0.4)';
      ctx.fill();
    });

    // Lines between close dots
    for (let i = 0; i < dots.length; i++) {
      for (let j = i + 1; j < dots.length; j++) {
        const dx = dots[i].x - dots[j].x;
        const dy = dots[i].y - dots[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.beginPath();
          ctx.moveTo(dots[i].x, dots[i].y);
          ctx.lineTo(dots[j].x, dots[j].y);
          ctx.strokeStyle = `rgba(200,255,0,${0.12 * (1 - dist / 100)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(draw);
  }

  resize();
  draw();
  window.addEventListener('resize', resize, { passive: true });
}

// ─── Scroll Reveal (IntersectionObserver) ────────────────────
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

document.querySelectorAll(
  '.reveal-up:not(.hero *), .reveal-float:not(.hero *), .fade-in, ' +
  '.about-left, .about-right, .stat-block, .skill-cat, .proj-card, ' +
  '.project-featured, .contact-left, .contact-right, .cform'
).forEach(el => {
  el.classList.add('reveal-up');
  revealObserver.observe(el);
});

// ─── Stat Counter ────────────────────────────────────────────
function countTo(el, target, dur = 1600) {
  let start = 0;
  const step = target / (dur / 16);
  const run = () => {
    start = Math.min(start + step, target);
    el.textContent = Math.floor(start);
    if (start < target) requestAnimationFrame(run);
  };
  requestAnimationFrame(run);
}

const statsObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      document.querySelectorAll('.stat-n').forEach(el => {
        countTo(el, parseInt(el.dataset.count));
      });
      statsObserver.disconnect();
    }
  });
}, { threshold: 0.5 });

const statsRow = document.querySelector('.stats-row');
if (statsRow) statsObserver.observe(statsRow);

// ─── Skills Tab Switcher ──────────────────────────────────────
const skillCats = document.querySelectorAll('.skill-cat');
const skillPanels = document.querySelectorAll('.skill-panel');

skillCats.forEach(cat => {
  cat.addEventListener('click', () => {
    skillCats.forEach(c => c.classList.remove('active'));
    skillPanels.forEach(p => p.classList.remove('active'));
    cat.classList.add('active');
    const panel = document.getElementById('panel-' + cat.dataset.cat);
    if (panel) {
      panel.classList.add('active');
      // Animate bars
      panel.querySelectorAll('.pbar-fill').forEach(bar => {
        bar.style.width = '0%';
        setTimeout(() => { bar.style.width = bar.dataset.w + '%'; }, 50);
      });
    }
  });
});

// Animate bars for the initially active panel
const skillsObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.skill-panel.active .pbar-fill').forEach(bar => {
        bar.style.width = bar.dataset.w + '%';
      });
      skillsObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

const skillsSection = document.getElementById('skills');
if (skillsSection) skillsObserver.observe(skillsSection);

// ─── Project Filter ───────────────────────────────────────────
const pfBtns = document.querySelectorAll('.pf-btn');
const projCards = document.querySelectorAll('.proj-card');
const featuredProject = document.querySelector('.project-featured');

pfBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    pfBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const filter = btn.dataset.f;

    // Handle featured project
    if (featuredProject) {
      const cat = featuredProject.dataset.cat;
      const show = filter === 'all' || filter === cat;
      featuredProject.style.transition = 'opacity 0.3s';
      featuredProject.style.opacity = show ? '1' : '0';
      setTimeout(() => { featuredProject.style.display = show ? 'grid' : 'none'; }, show ? 0 : 280);
      if (show) setTimeout(() => { featuredProject.style.opacity = '1'; }, 20);
    }

    projCards.forEach(card => {
      const cat = card.dataset.cat;
      const show = filter === 'all' || filter === cat;
      card.style.transition = 'opacity 0.3s, transform 0.3s';
      if (show) {
        card.classList.remove('hidden');
        requestAnimationFrame(() => { card.style.opacity = '1'; card.style.transform = 'translateY(0)'; });
      } else {
        card.style.opacity = '0';
        card.style.transform = 'translateY(10px)';
        setTimeout(() => card.classList.add('hidden'), 300);
      }
    });
  });
});

// ─── Contact Form ─────────────────────────────────────────────
const cform = document.getElementById('cform');
const cformSuccess = document.getElementById('cformSuccess');
const formBtnText = document.getElementById('formBtnText');

if (cform) {
  cform.addEventListener('submit', e => {
    e.preventDefault();
    const btn = cform.querySelector('button[type="submit"]');
    btn.disabled = true;
    formBtnText.textContent = 'Sending...';

    // Replace this setTimeout with your real API call (EmailJS, Formspree, etc.)
    setTimeout(() => {
      cform.reset();
      btn.disabled = false;
      formBtnText.textContent = 'Send Message';
      cformSuccess.classList.add('show');
      setTimeout(() => cformSuccess.classList.remove('show'), 5000);
    }, 1400);
  });
}

// ─── Smooth Scroll ────────────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

// ─── Parallax Hero ───────────────────────────────────────────
window.addEventListener('scroll', () => {
  const heroName = document.querySelector('.hero-name');
  if (heroName && window.scrollY < window.innerHeight) {
    heroName.style.transform = `translateY(${window.scrollY * 0.15}px)`;
  }
}, { passive: true });

// ─── Project Card Tilt ────────────────────────────────────────
document.querySelectorAll('.proj-card, .project-featured').forEach(card => {
  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width - 0.5) * 8;
    const y = ((e.clientY - r.top) / r.height - 0.5) * -8;
    card.style.transform = `perspective(800px) rotateX(${y}deg) rotateY(${x}deg) translateY(-6px)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = '';
  });
});

// ─── Text Scramble on Logo ────────────────────────────────────
const logo = document.querySelector('.logo');
if (logo) {
  const original = logo.textContent;
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ[]';
  logo.addEventListener('mouseenter', () => {
    let iter = 0;
    const maxIter = 12;
    const interval = setInterval(() => {
      logo.innerHTML = original.split('').map((c, i) => {
        if (c === '[' || c === ']') return `<span class="logo-bracket">${c}</span>`;
        if (iter > i * 1.2) return c;
        return chars[Math.floor(Math.random() * chars.length)];
      }).join('');
      if (iter >= maxIter) {
        clearInterval(interval);
        logo.innerHTML = '[<span class="logo-bracket"></span>AM<span class="logo-bracket">]</span>';
        logo.innerHTML = `<span class="logo-bracket">[</span>AM<span class="logo-bracket">]</span>`;
      }
      iter++;
    }, 40);
  });
}
