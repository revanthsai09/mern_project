# 🔥 Alex Mercer — Premium Portfolio v2

A premium, hand-crafted portfolio website built with pure **HTML5, CSS3, and Vanilla JS** — zero frameworks, zero dependencies. Designed to make a strong impression and showcase full-stack development skills.

---

## ✨ Premium Features

| Feature | Description |
|---|---|
| 🎬 Loader animation | Branded intro screen with animated progress bar |
| 🎯 Magnetic cursor | Custom cursor with ring follower + expand on hover |
| 🌐 Dot particle canvas | Interactive animated background — particles react to mouse |
| 📜 Scroll reveal | Elements fade/slide in as you scroll |
| 🔢 Stat counters | Numbers count up when the stats section enters viewport |
| 🧠 Skills switcher | Click frontend/backend/database/devops — tabs animate bars |
| 🖼 Project filter | Filter projects by category with smooth transitions |
| 🃏 3D card tilt | Project cards tilt on mouse movement using perspective |
| 🔤 Text scramble | Logo scrambles on hover, then resolves back |
| 🏷 Marquee ticker | Auto-scrolling tech stack ticker (pauses on hover) |
| 💬 Browser mockup | Animated shimmer mockup on featured project |
| 📬 Contact form | Submit with loading state + success message |
| 📱 Fully responsive | Mobile menu, stacked layouts, touch-friendly |
| 🎨 Noise texture | Subtle grain overlay for premium feel |

---

## 📁 Structure

```
portfolio/
├── index.html           ← Complete single-page portfolio
├── css/
│   └── style.css        ← ~580 lines — CSS variables, responsive, animations
├── js/
│   └── main.js          ← ~220 lines — all interactions
├── assets/
│   └── resume.pdf       ← Replace with your actual resume
└── README.md
```

---

## 🎨 Customization

### Your Info
In `index.html`, search and replace:
- `Alex Mercer` → your name
- `AM` → your initials
- `alex@example.com` → your email
- `+91 98765 43210` → your phone
- `Hyderabad, India` → your city
- GitHub, LinkedIn, Twitter links
- `data-count` values in stats row

### Profile Photo
Replace the `.photo-placeholder` div with:
```html
<img src="assets/photo.jpg" alt="Your Name" style="width:100%;height:100%;object-fit:cover;"/>
```

### Projects
Each project card has:
- `data-cat="fullstack"` — change to `frontend` or `backend` for filtering
- Icon emoji, title, description, stack tags, and links

### Colors
In `css/style.css`, update `:root`:
```css
--accent: #c8ff00;    /* neon green — change to any color */
--bg: #0c0c0c;        /* dark background */
```

### Contact Form (make it real)
The form currently simulates a send. To make it real:

**Option A — Formspree (free, easiest):**
1. Sign up at https://formspree.io
2. Change the form tag:
```html
<form action="https://formspree.io/f/YOUR_ID" method="POST">
```
3. Remove the JS form handler

**Option B — EmailJS (no backend):**
1. Sign up at https://emailjs.com
2. Add their SDK and replace the `setTimeout` in `main.js` with:
```js
emailjs.send('YOUR_SERVICE', 'YOUR_TEMPLATE', {
  name: document.getElementById('cname').value,
  email: document.getElementById('cemail').value,
  message: document.getElementById('cmessage').value,
});
```

---

## 🚀 Deploy to GitHub Pages

```bash
# 1. Go into the folder
cd portfolio

# 2. Initialize git
git init

# 3. Stage everything
git add .

# 4. First commit
git commit -m "🚀 feat: launch portfolio website"

# 5. Create GitHub repo, then:
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git branch -M main
git push -u origin main
```

Then in your GitHub repo: **Settings → Pages → Source: Deploy from a branch → main → / (root) → Save**

Your site will be live at: `https://YOUR_USERNAME.github.io/portfolio`

---

## 🌐 Deploy to Netlify (Alternative — faster)

1. Drag and drop the `portfolio` folder at https://app.netlify.com/drop
2. Done! You get a live URL instantly.

Or connect to GitHub and get auto-deploys on every push.

---

## 💡 Tips

- Add a real photo for maximum impact
- Fill in real project links (live demo + GitHub repos)
- Update the stack tags to match your actual skills
- Link your actual GitHub/LinkedIn profiles
- Test on mobile before sharing

---

## 📄 License

MIT — free to use, modify, and distribute.
